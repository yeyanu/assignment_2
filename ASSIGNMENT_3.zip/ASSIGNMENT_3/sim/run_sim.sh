#!/bin/bash
# run_sim.sh
cd /home/synopsis/ANISH_DEY/ASSIGNMENT_3/sim

# Compile with SVA explicitly enabled
vcs -sverilog -debug_access+all -kdb -full64 -assert enable_diag \
    ../src/cdc_interface.sv \
    ../src/cdc_fsms.sv \
    ../src/cdc_naive_top.sv \
    ../src/cdc_fixed_top.sv \
    ../src/tb_cdc_top.sv \
    -l vcs_compile.log

# Execute simulation binary and dump FSDB
./simv -ucli -i dump.tcl -l vcs_simulate.log

# Launch Verdi to view the waveforms
verdi -ssf cdc_simulation.fsdb &