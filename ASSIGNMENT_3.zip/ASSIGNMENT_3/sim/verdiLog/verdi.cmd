verdiSetActWin -dock widgetDock_<Message>
simSetSimulator "-vcssv" -exec "/home/synopsis/ANISH_DEY/ASSIGNMENT_3/sim/simv" \
           -args "-ucli"
debImport "-dbdir" "/home/synopsis/ANISH_DEY/ASSIGNMENT_3/sim/simv.daidir"
debLoadSimResult /home/synopsis/ANISH_DEY/ASSIGNMENT_3/sim/cdc_simulation.fsdb
wvCreateWindow
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcSelect -all -win $_nTrace1
srcSelect -win $_nTrace1 -range {1 98 1 2 1 1}
wvAddSignal -win $_nWave2 "/tb_cdc_top/clkA" "/tb_cdc_top/rstA_n" \
           "/tb_cdc_top/clkB" "/tb_cdc_top/rstB_n" "/tb_cdc_top/trigger_en_n" \
           "/tb_cdc_top/burst_mode_n" "/tb_cdc_top/trigger_en_f" \
           "/tb_cdc_top/burst_mode_f" "/tb_cdc_top/naive_exec\[7:0\]" \
           "/tb_cdc_top/naive_prod\[7:0\]" "/tb_cdc_top/u_naive/clkA" \
           "/tb_cdc_top/u_naive/rstA_n" "/tb_cdc_top/u_naive/clkB" \
           "/tb_cdc_top/u_naive/rstB_n" "/tb_cdc_top/u_naive/trigger_en" \
           "/tb_cdc_top/u_naive/burst_mode" \
           "/tb_cdc_top/u_naive/exec_count\[7:0\]" \
           "/tb_cdc_top/u_naive/producer_pulse_count\[7:0\]" \
           "/tb_cdc_top/fixed_exec\[7:0\]" "/tb_cdc_top/fixed_prod\[7:0\]" \
           "/tb_cdc_top/u_fixed/clkA" "/tb_cdc_top/u_fixed/rstA_n" \
           "/tb_cdc_top/u_fixed/clkB" "/tb_cdc_top/u_fixed/rstB_n" \
           "/tb_cdc_top/u_fixed/trigger_en" "/tb_cdc_top/u_fixed/burst_mode" \
           "/tb_cdc_top/u_fixed/exec_count\[7:0\]" \
           "/tb_cdc_top/u_fixed/producer_pulse_count\[7:0\]"
wvSetPosition -win $_nWave2 {("G1" 0)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1/tb_cdc_top" 0)}
wvAddSubGroup -win $_nWave2 -holdpost {tb_cdc_top}
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
verdiSetActWin -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomIn -win $_nWave2
srcDeselectAll -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
debExit
