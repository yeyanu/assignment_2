fsdbDumpfile "cdc_simulation.fsdb"
fsdbDumpvars 0 "tb_cdc_top"
run
exit