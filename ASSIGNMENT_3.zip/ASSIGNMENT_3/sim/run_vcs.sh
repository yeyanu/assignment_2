#!/bin/bash
# run_vcs.sh
cd /home/synopsis/ANISH_DEY/ASSIGNMENT_3/sim

# Compile and run strictly in the terminal
vcs -sverilog -full64 -assert enable_diag \
    ../src/cdc_interface.sv \
    ../src/cdc_fsms.sv \
    ../src/cdc_naive_top.sv \
    ../src/cdc_fixed_top.sv \
    ../src/tb_cdc_top.sv

./simv