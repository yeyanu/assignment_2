# run_pt.tcl
set target_library "/home/synopsis/SYNOPSYS_LIBRARY/NangateOpenCellLibrary_fast.db"
set link_library   [concat "*" $target_library]

# Load synthesized netlist from the synth directory
read_verilog ../synth/cdc_fixed_netlist.v
current_design cdc_fixed_top
link
read_sdc ../synth/cdc_fixed_out.sdc

# 1. Prove Asynchronous Exception (Will report "unconstrained" or "ignored")
report_timing -from [get_clocks clkA] -to [get_clocks clkB] > pt_cdc_exception_proof.rpt

# 2. Report Reset Recovery and Removal for Domain A
report_timing -from [get_ports rstA_n] -to [all_registers -clock clkA] -delay_type max > pt_reset_recovery.rpt
report_timing -from [get_ports rstA_n] -to [all_registers -clock clkA] -delay_type min > pt_reset_removal.rpt

exit