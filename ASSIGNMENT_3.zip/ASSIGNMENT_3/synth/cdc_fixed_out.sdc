###################################################################

# Created by write_sdc on Tue Oct 13 14:03:56 2026

###################################################################
set sdc_version 2.1

set_units -time ns -resistance MOhm -capacitance fF -voltage V -current mA
create_clock [get_ports clkA]  -period 10  -waveform {0 5}
create_clock [get_ports clkB]  -period 33  -waveform {0 16.5}
set_clock_groups  -asynchronous -name clkA_1  -group [get_clocks clkA] -group  \
[get_clocks clkB]
