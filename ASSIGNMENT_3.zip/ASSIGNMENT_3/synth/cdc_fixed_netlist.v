/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Tue Oct 13 14:03:56 2026
/////////////////////////////////////////////////////////////


module cdc_fixed_top ( clkA, rstA_n, clkB, rstB_n, trigger_en, burst_mode, 
        exec_count, producer_pulse_count );
  output [7:0] exec_count;
  output [7:0] producer_pulse_count;
  input clkA, rstA_n, clkB, rstB_n, trigger_en, burst_mode;
  wire   req_a, ack_sync_a, \cdc_bus.cmd_pulse_a , req_sync_b, req_meta_b,
         req_sync_b_dly, \cdc_bus.done_pulse_b , ack_b, ack_meta_a,
         ack_sync_a_dly, \u_executor/N16 , \u_executor/state[0] , n28, n29,
         n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43,
         n44, n45, n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57,
         n58, n59, n60, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72,
         n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86,
         n87, n88, n89, n90;
  wire   [2:0] \u_producer/state ;

  DFFR_X1 \u_executor/intf.done_pulse_b_reg  ( .D(\u_executor/N16 ), .CK(clkB), 
        .RN(rstB_n), .Q(\cdc_bus.done_pulse_b ) );
  DFFR_X1 ack_b_reg ( .D(n50), .CK(clkB), .RN(rstB_n), .Q(ack_b) );
  DFFR_X1 ack_meta_a_reg ( .D(ack_b), .CK(clkA), .RN(rstA_n), .Q(ack_meta_a)
         );
  DFFR_X1 ack_sync_a_reg ( .D(ack_meta_a), .CK(clkA), .RN(rstA_n), .Q(
        ack_sync_a), .QN(n80) );
  DFFR_X1 ack_sync_a_dly_reg ( .D(ack_sync_a), .CK(clkA), .RN(rstA_n), .Q(
        ack_sync_a_dly) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[0]  ( .D(n43), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[0]) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[1]  ( .D(n42), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[1]), .QN(n81) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[2]  ( .D(n41), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[2]) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[3]  ( .D(n40), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[3]), .QN(n83) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[4]  ( .D(n39), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[4]) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[5]  ( .D(n38), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[5]), .QN(n85) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[6]  ( .D(n37), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[6]) );
  DFFR_X1 \u_producer/producer_pulse_count_reg[7]  ( .D(n36), .CK(clkA), .RN(
        rstA_n), .Q(producer_pulse_count[7]) );
  DFFR_X1 \u_producer/intf.cmd_pulse_a_reg  ( .D(n51), .CK(clkA), .RN(rstA_n), 
        .Q(\cdc_bus.cmd_pulse_a ) );
  DFFR_X1 req_a_reg ( .D(n49), .CK(clkA), .RN(rstA_n), .Q(req_a) );
  DFFR_X1 req_meta_b_reg ( .D(req_a), .CK(clkB), .RN(rstB_n), .Q(req_meta_b)
         );
  DFFR_X1 req_sync_b_reg ( .D(req_meta_b), .CK(clkB), .RN(rstB_n), .Q(
        req_sync_b), .QN(n90) );
  DFFR_X1 req_sync_b_dly_reg ( .D(req_sync_b), .CK(clkB), .RN(rstB_n), .Q(
        req_sync_b_dly) );
  DFFR_X1 \u_executor/state_reg[0]  ( .D(n48), .CK(clkB), .RN(rstB_n), .Q(
        \u_executor/state[0] ), .QN(n89) );
  DFFR_X1 \u_executor/state_reg[1]  ( .D(n47), .CK(clkB), .RN(rstB_n), .QN(n79) );
  DFFR_X1 \u_producer/state_reg[0]  ( .D(n44), .CK(clkA), .RN(rstA_n), .Q(
        \u_producer/state [0]), .QN(n87) );
  DFFR_X1 \u_producer/state_reg[1]  ( .D(n45), .CK(clkA), .RN(rstA_n), .Q(
        \u_producer/state [1]) );
  DFFR_X1 \u_producer/state_reg[2]  ( .D(n46), .CK(clkA), .RN(rstA_n), .Q(
        \u_producer/state [2]), .QN(n88) );
  DFFR_X1 \u_logger/exec_count_reg[0]  ( .D(n35), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[0]) );
  DFFR_X1 \u_logger/exec_count_reg[1]  ( .D(n34), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[1]), .QN(n82) );
  DFFR_X1 \u_logger/exec_count_reg[2]  ( .D(n33), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[2]) );
  DFFR_X1 \u_logger/exec_count_reg[3]  ( .D(n32), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[3]), .QN(n84) );
  DFFR_X1 \u_logger/exec_count_reg[4]  ( .D(n31), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[4]) );
  DFFR_X1 \u_logger/exec_count_reg[5]  ( .D(n30), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[5]), .QN(n86) );
  DFFR_X1 \u_logger/exec_count_reg[6]  ( .D(n29), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[6]) );
  DFFR_X1 \u_logger/exec_count_reg[7]  ( .D(n28), .CK(clkA), .RN(rstA_n), .Q(
        exec_count[7]) );
  AOI21_X1 U55 ( .B1(req_sync_b), .B2(ack_b), .A(\cdc_bus.done_pulse_b ), .ZN(
        n52) );
  INV_X1 U56 ( .A(n52), .ZN(n50) );
  AOI21_X1 U57 ( .B1(req_a), .B2(n80), .A(\cdc_bus.cmd_pulse_a ), .ZN(n53) );
  INV_X1 U58 ( .A(n53), .ZN(n49) );
  AOI221_X1 U59 ( .B1(req_sync_b_dly), .B2(n79), .C1(n90), .C2(n79), .A(
        \u_executor/state[0] ), .ZN(n48) );
  NOR2_X1 U60 ( .A1(n89), .A2(n79), .ZN(\u_executor/N16 ) );
  AOI21_X1 U61 ( .B1(n89), .B2(n79), .A(\u_executor/N16 ), .ZN(n47) );
  NOR2_X1 U62 ( .A1(\u_producer/state [0]), .A2(\u_producer/state [1]), .ZN(
        n62) );
  INV_X1 U63 ( .A(trigger_en), .ZN(n54) );
  NAND2_X1 U64 ( .A1(n62), .A2(n54), .ZN(n55) );
  AOI211_X1 U65 ( .C1(\u_producer/state [2]), .C2(n55), .A(req_a), .B(
        ack_sync_a), .ZN(n60) );
  NOR2_X1 U66 ( .A1(\u_producer/state [1]), .A2(burst_mode), .ZN(n59) );
  AOI22_X1 U67 ( .A1(\u_producer/state [0]), .A2(\u_producer/state [1]), .B1(
        n59), .B2(n87), .ZN(n56) );
  NAND2_X1 U68 ( .A1(n60), .A2(n55), .ZN(n58) );
  OAI22_X1 U69 ( .A1(n60), .A2(n88), .B1(n56), .B2(n58), .ZN(n46) );
  NAND2_X1 U70 ( .A1(n60), .A2(\u_producer/state [0]), .ZN(n57) );
  XNOR2_X1 U71 ( .A(\u_producer/state [1]), .B(n57), .ZN(n45) );
  OAI33_X1 U73 ( .A1(1'b0), .A2(n60), .A3(n87), .B1(\u_producer/state [0]), 
        .B2(n59), .B3(n58), .ZN(n44) );
  AOI22_X1 U74 ( .A1(\u_producer/state [0]), .A2(\u_producer/state [1]), .B1(
        n62), .B2(trigger_en), .ZN(n63) );
  NOR4_X1 U75 ( .A1(n63), .A2(\u_producer/state [2]), .A3(ack_sync_a), .A4(
        req_a), .ZN(n51) );
  XOR2_X1 U76 ( .A(n51), .B(producer_pulse_count[0]), .Z(n43) );
  NAND2_X1 U77 ( .A1(n51), .A2(producer_pulse_count[0]), .ZN(n64) );
  NOR2_X1 U78 ( .A1(n64), .A2(n81), .ZN(n65) );
  AOI21_X1 U79 ( .B1(n64), .B2(n81), .A(n65), .ZN(n42) );
  XOR2_X1 U80 ( .A(n65), .B(producer_pulse_count[2]), .Z(n41) );
  NAND2_X1 U81 ( .A1(n65), .A2(producer_pulse_count[2]), .ZN(n66) );
  NOR2_X1 U82 ( .A1(n66), .A2(n83), .ZN(n67) );
  AOI21_X1 U83 ( .B1(n66), .B2(n83), .A(n67), .ZN(n40) );
  XOR2_X1 U84 ( .A(n67), .B(producer_pulse_count[4]), .Z(n39) );
  NAND2_X1 U85 ( .A1(n67), .A2(producer_pulse_count[4]), .ZN(n68) );
  NOR2_X1 U86 ( .A1(n68), .A2(n85), .ZN(n69) );
  AOI21_X1 U87 ( .B1(n68), .B2(n85), .A(n69), .ZN(n38) );
  XOR2_X1 U88 ( .A(n69), .B(producer_pulse_count[6]), .Z(n37) );
  NAND2_X1 U89 ( .A1(n69), .A2(producer_pulse_count[6]), .ZN(n70) );
  XNOR2_X1 U90 ( .A(producer_pulse_count[7]), .B(n70), .ZN(n36) );
  NOR2_X1 U91 ( .A1(ack_sync_a_dly), .A2(n80), .ZN(n71) );
  XOR2_X1 U92 ( .A(n71), .B(exec_count[0]), .Z(n35) );
  NAND2_X1 U93 ( .A1(n71), .A2(exec_count[0]), .ZN(n72) );
  NOR2_X1 U94 ( .A1(n72), .A2(n82), .ZN(n73) );
  AOI21_X1 U95 ( .B1(n72), .B2(n82), .A(n73), .ZN(n34) );
  XOR2_X1 U96 ( .A(n73), .B(exec_count[2]), .Z(n33) );
  NAND2_X1 U97 ( .A1(n73), .A2(exec_count[2]), .ZN(n74) );
  NOR2_X1 U98 ( .A1(n74), .A2(n84), .ZN(n75) );
  AOI21_X1 U99 ( .B1(n74), .B2(n84), .A(n75), .ZN(n32) );
  XOR2_X1 U100 ( .A(n75), .B(exec_count[4]), .Z(n31) );
  NAND2_X1 U101 ( .A1(n75), .A2(exec_count[4]), .ZN(n76) );
  NOR2_X1 U102 ( .A1(n76), .A2(n86), .ZN(n77) );
  AOI21_X1 U103 ( .B1(n76), .B2(n86), .A(n77), .ZN(n30) );
  XOR2_X1 U104 ( .A(n77), .B(exec_count[6]), .Z(n29) );
  NAND2_X1 U105 ( .A1(n77), .A2(exec_count[6]), .ZN(n78) );
  XNOR2_X1 U106 ( .A(exec_count[7]), .B(n78), .ZN(n28) );
endmodule

