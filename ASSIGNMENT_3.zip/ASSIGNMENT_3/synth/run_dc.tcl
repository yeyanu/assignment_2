# run_dc.tcl
set target_library    "/home/synopsis/SYNOPSYS_LIBRARY/NangateOpenCellLibrary_fast.db"
set synthetic_library "/home/synopsis/SYNOPSYS_LIBRARY/dw_foundation.sldb"
set link_library      [concat "*" $target_library $synthetic_library]

# Read only the fixed 4-phase design for synthesis
analyze -format sverilog {../src/cdc_interface.sv ../src/cdc_fsms.sv ../src/cdc_fixed_top.sv}
elaborate cdc_fixed_top
current_design cdc_fixed_top
link
uniquify

# Apply clock groups
source cdc_constraints.sdc
compile_ultra

# Export Netlist and generated constraints for STA
write -format verilog -hierarchy -output cdc_fixed_netlist.v
write_sdc cdc_fixed_out.sdc

report_area > synth_area.rpt
report_timing > synth_timing.rpt
exit