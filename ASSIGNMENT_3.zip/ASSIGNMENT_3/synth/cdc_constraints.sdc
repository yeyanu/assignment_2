create_clock -name clkA -period 10.0 [get_ports clkA]
create_clock -name clkB -period 33.0 [get_ports clkB]

# The assignment requirement: Mask timing across the CDC boundary
set_clock_groups -asynchronous -group [get_clocks clkA] -group [get_clocks clkB]