#!/bin/bash
# run_lint.sh
cd /home/synopsis/ANISH_DEY/ASSIGNMENT_3/lint

vcs -full64 -sverilog -lint=all -kdb \
    ../src/cdc_interface.sv \
    ../src/cdc_fsms.sv \
    ../src/cdc_naive_top.sv \
    ../src/cdc_fixed_top.sv \
    ../src/tb_cdc_top.sv \
    | tee vcs_lint_report.log
