`timescale 1ns/1ps

interface cdc_if (
    input logic clkA,
    input logic clkB,
    input logic rst_n
);
    logic cmd_pulse_a;
    logic cmd_pulse_sync_b;
    logic done_pulse_b;
    logic done_pulse_sync_a;
    logic cdc_busy;

    modport producer (output cmd_pulse_a, input cdc_busy);
    modport executor (input cmd_pulse_sync_b, output done_pulse_b);
    modport logger   (input done_pulse_sync_a);

    // =========================================================================
    // SYSTEMVERILOG MULTI-CLOCK ASSERTIONS (SVA)
    // =========================================================================
    
    // 1. Verify A -> B Crossing
    property p_cmd_crosses_safely;
        @(posedge clkA) disable iff (!rst_n)
        cmd_pulse_a |=> @(posedge clkB) ##[1:50] cmd_pulse_sync_b;
    endproperty

    assert_cmd_crosses: assert property (p_cmd_crosses_safely)
        $info("[%0t] [SVA PASS] cmd_pulse safely reached Domain B", $time);
    else 
        $error("[%0t] [SVA FAIL] cmd_pulse SWALLOWED across boundary!", $time);

    // 2. Verify B -> A Crossing
    property p_done_crosses_safely;
        @(posedge clkB) disable iff (!rst_n)
        done_pulse_b |=> @(posedge clkA) ##[1:50] done_pulse_sync_a;
    endproperty

    assert_done_crosses: assert property (p_done_crosses_safely)
        $info("[%0t] [SVA PASS] done_pulse safely reached Domain A", $time);
    else 
        $error("[%0t] [SVA FAIL] done_pulse SWALLOWED across boundary!", $time);

endinterface