`timescale 1ns/1ps

module cdc_naive_top (
    input  logic clkA, input logic rstA_n,
    input  logic clkB, input logic rstB_n,
    input  logic trigger_en, input logic burst_mode,
    output logic [7:0] exec_count,
    output logic [7:0] producer_pulse_count
);
    cdc_if cdc_bus (.clkA(clkA), .clkB(clkB), .rst_n(rstA_n & rstB_n));
    assign cdc_bus.cdc_busy = 1'b0; // Flaw: No backpressure

    producer_fsm u_producer (.*, .intf(cdc_bus.producer));

    // A->B Naive Sync
    logic cmd_meta;
    always_ff @(posedge clkB or negedge rstB_n) begin
        if (!rstB_n) {cdc_bus.cmd_pulse_sync_b, cmd_meta} <= 2'b00;
        else         {cdc_bus.cmd_pulse_sync_b, cmd_meta} <= {cmd_meta, cdc_bus.cmd_pulse_a};
    end

    executor_fsm u_executor (.*, .intf(cdc_bus.executor));

    // B->A Naive Sync
    logic done_meta;
    always_ff @(posedge clkA or negedge rstA_n) begin
        if (!rstA_n) {cdc_bus.done_pulse_sync_a, done_meta} <= 2'b00;
        else         {cdc_bus.done_pulse_sync_a, done_meta} <= {done_meta, cdc_bus.done_pulse_b};
    end

    logger_fsm u_logger (.*, .intf(cdc_bus.logger));
endmodule