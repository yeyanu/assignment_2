`timescale 1ns/1ps

module tb_cdc_top;
    logic clkA = 0; logic rstA_n = 0;
    logic clkB = 0; logic rstB_n = 0;

    // Separate control signals for true independent threading
    logic trigger_en_n = 0; logic burst_mode_n = 0;
    logic trigger_en_f = 0; logic burst_mode_f = 0;

    // 10ns vs 33ns -> Guaranteed phase drift
    always #5 clkA = ~clkA;
    always #16.5 clkB = ~clkB;

    logic [7:0] naive_exec, naive_prod;
    cdc_naive_top u_naive (
        .clkA(clkA), .rstA_n(rstA_n), .clkB(clkB), .rstB_n(rstB_n),
        .trigger_en(trigger_en_n), .burst_mode(burst_mode_n),
        .exec_count(naive_exec), .producer_pulse_count(naive_prod)
    );

    logic [7:0] fixed_exec, fixed_prod;
    cdc_fixed_top u_fixed (
        .clkA(clkA), .rstA_n(rstA_n), .clkB(clkB), .rstB_n(rstB_n),
        .trigger_en(trigger_en_f), .burst_mode(burst_mode_f),
        .exec_count(fixed_exec), .producer_pulse_count(fixed_prod)
    );

    initial begin
        $display("=================================================");
        $display(" MULTI-THREADED CDC SIMULATION STARTED");
        $display("=================================================");
        
        #50; rstA_n = 1; rstB_n = 1; #100;

        // Run both stimulus sequences entirely in parallel
        fork
            // -----------------------------------------------------
            // THREAD 1: Drive Naive Design
            // -----------------------------------------------------
            begin
                $display("[%0t] [NAIVE THREAD] Firing Single Command", $time);
                @(posedge clkA) trigger_en_n = 1; burst_mode_n = 0;
                @(posedge clkA) trigger_en_n = 0;
                
                #500;
                
                $display("[%0t] [NAIVE THREAD] Firing Burst Command", $time);
                @(posedge clkA) trigger_en_n = 1; burst_mode_n = 1;
                @(posedge clkA) trigger_en_n = 0;
                
                #2500;
            end

            // -----------------------------------------------------
            // THREAD 2: Drive Fixed (4-Phase) Design
            // -----------------------------------------------------
            begin
                $display("[%0t] [FIXED THREAD] Firing Single Command", $time);
                @(posedge clkA) trigger_en_f = 1; burst_mode_f = 0;
                @(posedge clkA) trigger_en_f = 0;
                
                #500;
                
                $display("[%0t] [FIXED THREAD] Firing Burst Command", $time);
                @(posedge clkA) trigger_en_f = 1; burst_mode_f = 1;
                @(posedge clkA) trigger_en_f = 0;
                
                #2500; // Allow sufficient time for the slow 4-phase logic to complete
            end
        join

        // Execution resumes here only after BOTH threads have completely finished

        $display("\n=================================================");
        $display(" FINAL VERIFICATION SCOREBOARD");
        $display("=================================================");
        
        $display("\n--- NAIVE DESIGN (Expected Failure) ---");
        $display("   Pulses Issued : %0d", naive_prod);
        $display("   Pulses Logged : %0d", naive_exec);
        if (naive_prod > naive_exec)
            $display("   VERDICT       : FAIL (Pulse successfully swallowed!)");
        else
            $display("   VERDICT       : PASS");

        $display("\n--- FIXED (4-PHASE) DESIGN (Expected Perfect) ---");
        $display("   Pulses Issued : %0d", fixed_prod);
        $display("   Pulses Logged : %0d", fixed_exec);
        if (fixed_prod == fixed_exec && fixed_prod > 0)
            $display("   VERDICT       : PASS (Zero data loss across boundary!)");
        else
            $display("   VERDICT       : FAIL");

        $display("=================================================\n");
        $finish;
    end
endmodule