`timescale 1ns/1ps

module cdc_fixed_top (
    input  logic clkA, input logic rstA_n,
    input  logic clkB, input logic rstB_n,
    input  logic trigger_en, input logic burst_mode,
    output logic [7:0] exec_count,
    output logic [7:0] producer_pulse_count
);
    cdc_if cdc_bus (.clkA(clkA), .clkB(clkB), .rst_n(rstA_n & rstB_n));

    logic req_a, ack_b, req_meta_b, req_sync_b, req_sync_b_dly, ack_meta_a, ack_sync_a, ack_sync_a_dly;
    assign cdc_bus.cdc_busy = req_a | ack_sync_a; // Fix: 4-phase stall

    producer_fsm u_producer (.*, .intf(cdc_bus.producer));

    always_ff @(posedge clkA or negedge rstA_n) begin
        if (!rstA_n)                  req_a <= 1'b0;
        else if (cdc_bus.cmd_pulse_a) req_a <= 1'b1;
        else if (ack_sync_a)          req_a <= 1'b0; 
    end

    always_ff @(posedge clkB or negedge rstB_n) begin
        if (!rstB_n) {req_sync_b_dly, req_sync_b, req_meta_b} <= 3'b000;
        else         {req_sync_b_dly, req_sync_b, req_meta_b} <= {req_sync_b, req_meta_b, req_a};
    end
    assign cdc_bus.cmd_pulse_sync_b = req_sync_b & ~req_sync_b_dly;

    executor_fsm u_executor (.*, .intf(cdc_bus.executor));

    always_ff @(posedge clkB or negedge rstB_n) begin
        if (!rstB_n)                   ack_b <= 1'b0;
        else if (cdc_bus.done_pulse_b) ack_b <= 1'b1;
        else if (!req_sync_b)          ack_b <= 1'b0;
    end

    always_ff @(posedge clkA or negedge rstA_n) begin
        if (!rstA_n) {ack_sync_a_dly, ack_sync_a, ack_meta_a} <= 3'b000;
        else         {ack_sync_a_dly, ack_sync_a, ack_meta_a} <= {ack_sync_a, ack_meta_a, ack_b};
    end
    assign cdc_bus.done_pulse_sync_a = ack_sync_a & ~ack_sync_a_dly;

    logger_fsm u_logger (.*, .intf(cdc_bus.logger));
endmodule