`timescale 1ns/1ps

module producer_fsm (
    input  logic clkA,
    input  logic rstA_n,
    input  logic trigger_en,
    input  logic burst_mode,
    output logic [7:0] producer_pulse_count,
    cdc_if.producer intf
);
    typedef enum logic [2:0] {IDLE, WAIT_1, WAIT_2, SEND_2, COOLDOWN} state_t;
    state_t state;

    always_ff @(posedge clkA or negedge rstA_n) begin
        if (!rstA_n) begin
            state <= IDLE;
            intf.cmd_pulse_a <= 1'b0;
            producer_pulse_count <= 8'd0;
        end else begin
            intf.cmd_pulse_a <= 1'b0;
            case (state)
                IDLE: begin
                    if (trigger_en && !intf.cdc_busy) begin
                        intf.cmd_pulse_a <= 1'b1;
                        producer_pulse_count <= producer_pulse_count + 1'b1;
                        $display("[%0t] [PRODUCER] Issued cmd_pulse. Total: %0d", $time, producer_pulse_count + 1);
                        state <= burst_mode ? WAIT_1 : COOLDOWN;
                    end
                end
                WAIT_1: if (!intf.cdc_busy) state <= WAIT_2;
                WAIT_2: if (!intf.cdc_busy) state <= SEND_2;
                SEND_2: begin
                    if (!intf.cdc_busy) begin
                        intf.cmd_pulse_a <= 1'b1;
                        producer_pulse_count <= producer_pulse_count + 1'b1;
                        $display("[%0t] [PRODUCER] Issued burst cmd_pulse. Total: %0d", $time, producer_pulse_count + 1);
                        state <= COOLDOWN;
                    end
                end
                COOLDOWN: begin
                    if (!trigger_en && !intf.cdc_busy) state <= IDLE;
                end
            endcase
        end
    end
endmodule

module executor_fsm (
    input logic clkB,
    input logic rstB_n,
    cdc_if.executor intf
);
    typedef enum logic [1:0] {IDLE, EXEC_1, EXEC_2, EXEC_3} state_t;
    state_t state;

    always_ff @(posedge clkB or negedge rstB_n) begin
        if (!rstB_n) begin
            state <= IDLE;
            intf.done_pulse_b <= 1'b0;
        end else begin
            intf.done_pulse_b <= 1'b0;
            case (state)
                IDLE: begin
                    if (intf.cmd_pulse_sync_b) begin
                        $display("[%0t] [EXECUTOR] Command received. Starting execution (3 cycles).", $time);
                        state <= EXEC_1;
                    end
                end
                EXEC_1: state <= EXEC_2;
                EXEC_2: state <= EXEC_3;
                EXEC_3: begin
                    intf.done_pulse_b <= 1'b1;
                    $display("[%0t] [EXECUTOR] Execution complete. Emitting done_pulse.", $time);
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule

module logger_fsm (
    input logic clkA,
    input logic rstA_n,
    output logic [7:0] exec_count,
    cdc_if.logger intf
);
    always_ff @(posedge clkA or negedge rstA_n) begin
        if (!rstA_n) exec_count <= 8'd0;
        else if (intf.done_pulse_sync_a) begin
            exec_count <= exec_count + 1'b1;
            $display("[%0t] [LOGGER] Done pulse recorded! Total Executions: %0d", $time, exec_count + 1);
        end
    end
endmodule