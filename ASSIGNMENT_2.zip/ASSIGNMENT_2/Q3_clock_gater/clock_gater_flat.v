/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Tue Oct 13 14:27:43 2026
/////////////////////////////////////////////////////////////


module clock_gater ( clk, en, gclk );
  input clk, en;
  output gclk;
  wire   en_latched;

  DLL_X1 en_latched_reg ( .D(en), .GN(clk), .Q(en_latched) );
  AND2_X1 U2 ( .A1(en_latched), .A2(clk), .ZN(gclk) );
endmodule

