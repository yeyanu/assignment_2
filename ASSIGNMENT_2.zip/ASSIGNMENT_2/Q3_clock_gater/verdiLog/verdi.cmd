simSetSimulator "-vcssv" -exec "./simv" -args "-l vcs_simulate.log" -uvmDebug on \
           -simDelim
debImport "-i" "-simflow" "-dbdir" "./simv.daidir"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcTBInvokeSim
verdiSetActWin -dock widgetDock_<Member>
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
debExit
